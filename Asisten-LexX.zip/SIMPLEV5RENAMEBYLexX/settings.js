/*

  !- Credits By LexX-Phantom
  https://wa.me/62895403920320
  
*/

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

//~~~~~~~~~~~ Settings Bot ~~~~~~~~~~~//
global.owner = '62895403920320'
global.versi = version
global.namaOwner = "LexX-Phantom"
global.packname = 'LexX-Phantom'
global.botname = 'LexX-Phantom'
global.botname2 = 'LexX-Phantom'

//~~~~~~~~~~~ Settings Link ~~~~~~~~~~//
global.linkOwner = "https://wa.me/62895403920320"
global.linkGrup = "https://chat.whatsapp.com/BLxnsaQ8iqQAo3QJUOeq5k"

//~~~~~~~~~~~ Settings Jeda ~~~~~~~~~~//
global.delayJpm = 3500
global.delayPushkontak = 6000

//~~~~~~~~~~ Settings Saluran ~~~~~~~~~//
global.linkSaluran = "https://whatsapp.com/channel/0029VavLUjT4yltLGbP3Dm07"
global.idSaluran = "120363375137712829@newsletter"
global.namaSaluran = "LexX-Phantom"

//~~~~~~~~~ Settings Orderkuota ~~~~~~~~//
global.merchantIdOrderKuota = ""
global.apiOrderKuota = ""
global.qrisOrderKuota = "https://img12.pixhost.to/images/558/571282502_lexxoffc.jpg"

//~~~~~~~~~~ Settings Apikey ~~~~~~~~~~//
global.apiDigitalOcean = ""
global.apiSimpleBot = "_"

//~~~~~~~~~ Settings Payment ~~~~~~~~~//
global.dana = "0895403920320"
global.ovo = "*close*"
global.gopay = "*close*"

//~~~~~~~~~~ Settings Image ~~~~~~~~~~//
global.image = {
menu: "https://img12.pixhost.to/images/558/571282339_lexxoffc.jpg", 
reply: "https://img12.pixhost.to/images/558/571282339_lexxoffc.jpg", 
logo: "https://img12.pixhost.to/images/558/571282339_lexxoffc.jpg", 
qris: "https://img12.pixhost.to/images/558/571282406_lexxoffc.jpg"
}

//~~~~~~~~~ Settings Api Panel ~~~~~~~~//
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://drayxpedo.draystore-private.biz.id"
global.apikey = "ptla_REqO8VqVyHZU5Q92JVBkem1MLGENFzn96h4dyegxCAB" //ptla
global.capikey = "ptlc_WKw8jaPCkOJYf7Nruk6Ism1cv5d5BFQDtwVCoj76XIB" //ptlc

//~~~~~~~~ Settings Api Panel 2 ~~~~~~~~//
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "1" // Location ID
global.domainV2 = "https://langzzxrangxyz.mysura.xyz"
global.apikeyV2 = "ptla_J8MMQyz8w4tCoO8WqX5xzawAzN5lwiuKf20qb2Y6BkO" //ptla
global.capikeyV2 = "ptlc_rmboZID9ANMS5vYWvr53688mFQMx80D9f9pcZEL7WuH" //ptlc

//~~~~~~~ Settings Api Subdomain ~~~~~~~//
global.subdomain = {
"serverku.biz.id": {
"zone": "4e4feaba70b41ed78295d2dcc090dd3a", 
"apitoken": "oof_QRNdUC4aMQ3xIB8dmkGaZu7rk2J-0P_tN55l"
}, 
"privatserver.my.id": {
"zone": "699bb9eb65046a886399c91daacb1968", 
"apitoken": "CrQMyDn2fhchlGne2ogAw7PvJLsg4x8vasBv__6D"
}, 
"panelwebsite.biz.id": {
"zone": "2d6aab40136299392d66eed44a7b1122", 
"apitoken": "cj17Lzg9otqwkYIVzgL0pcVA4GfcXqePHAOhCqa_"
}, 
"mypanelstore.web.id": {
"zone": "c61c442d70392500611499c5af816532", 
"apitoken": "N_VhWv2ZK6UJxLdCnxMfZx9PtzAdmPGM3HmOjZR4"
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "qRxwgS3Kl_ziCXti2p4BHbWTvGUYzAuYmVM28ZEp"
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "sH60tbg10UH8gpNrlYpf3UMse1CNJ01EKJ69YVqb"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "GRe4rg-vhb4c8iSjKCALHJC0LaxkzNPgmmgcDGpm"
}
}

//~~~~~~~~~~ Settings Message ~~~~~~~~//
global.mess = {
	owner: "*[fitur ini hanya khusus LexX]*",
	admin: "*[fitur ini hanya bisa admin grup]*",
	botAdmin: "*[bot bukan admin]*",
	group: "*[fitur ini khusus di dalam grub]*",
	private: "*[fitur ini khusus di private!!]*",
	prem: "*[fitur ini khusus bang LexX]*",
	wait: 'SBR DLU',
	error: 'GAGAL ',
	done: 'DONE BOSQU'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})